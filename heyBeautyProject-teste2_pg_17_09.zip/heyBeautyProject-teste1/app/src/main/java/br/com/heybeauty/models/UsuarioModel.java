package br.com.heybeauty.models;

public class UsuarioModel {

    String idUsuarioGeral;

    String geralNomecad;

    String geralDatNascicad;

    String geralEnderecocad;

    String geralEstadocad;

    String geralCidadecad;

    String geralTelcad;

    String geralEmailcad;

    String geralSenhacad;


    public UsuarioModel() {
    }


    public UsuarioModel(String idUsuarioGeral, String geralNomecad, String geralDatNascicad, String geralEnderecocad, String geralEstadocad, String geralCidadecad, String geralTelcad, String geralEmailcad, String geralSenhacad) {
        this.idUsuarioGeral = idUsuarioGeral;
        this.geralNomecad = geralNomecad;
        this.geralDatNascicad = geralDatNascicad;
        this.geralEnderecocad = geralEnderecocad;
        this.geralEstadocad = geralEstadocad;
        this.geralCidadecad = geralCidadecad;
        this.geralTelcad = geralTelcad;
        this.geralEmailcad = geralEmailcad;
        this.geralSenhacad = geralSenhacad;
    }


    public String getIdUsuarioGeral() {
        return idUsuarioGeral;
    }

    public void setIdUsuarioGeral(String idUsuarioGeral) {
        this.idUsuarioGeral = idUsuarioGeral;
    }

    public String getGeralNomecad() {
        return geralNomecad;
    }

    public void setGeralNomecad(String geralNomecad) {
        this.geralNomecad = geralNomecad;
    }

    public String getGeralDatNascicad() {
        return geralDatNascicad;
    }

    public void setGeralDatNascicad(String geralDatNascicad) {
        this.geralDatNascicad = geralDatNascicad;
    }

    public String getGeralEnderecocad() {
        return geralEnderecocad;
    }

    public void setGeralEnderecocad(String geralEnderecocad) {
        this.geralEnderecocad = geralEnderecocad;
    }

    public String getGeralEstadocad() {
        return geralEstadocad;
    }

    public void setGeralEstadocad(String geralEstadocad) {
        this.geralEstadocad = geralEstadocad;
    }

    public String getGeralCidadecad() {
        return geralCidadecad;
    }

    public void setGeralCidadecad(String geralCidadecad) {
        this.geralCidadecad = geralCidadecad;
    }

    public String getGeralTelcad() {
        return geralTelcad;
    }

    public void setGeralTelcad(String geralTelcad) {
        this.geralTelcad = geralTelcad;
    }

    public String getGeralEmailcad() {
        return geralEmailcad;
    }

    public void setGeralEmailcad(String geralEmailcad) {
        this.geralEmailcad = geralEmailcad;
    }

    public String getGeralSenhacad() {
        return geralSenhacad;
    }

    public void setGeralSenhacad(String geralSenhacad) {
        this.geralSenhacad = geralSenhacad;
    }


    @Override
    public String toString() {
        return geralNomecad;
    }






}
/**fim da class*/