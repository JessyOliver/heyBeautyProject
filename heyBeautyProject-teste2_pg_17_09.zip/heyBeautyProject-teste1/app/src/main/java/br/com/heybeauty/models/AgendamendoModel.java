package br.com.heybeauty.models;

import java.sql.Timestamp;

public class AgendamendoModel {
    private String idCliente;
    private String idAgendamento;
    private Timestamp data;
    private String Status;

    public AgendamendoModel() {
    }

    public AgendamendoModel(String idCliente, String idAgendamento, Timestamp data, String status) {
        this.idCliente = idCliente;
        this.idAgendamento = idAgendamento;
        this.data = data;
        Status = status;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(String idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public Timestamp getData() {
        return data;
    }

    public void setData(Timestamp data) {
        this.data = data;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

}
