package br.com.heybeauty.TelaPrincipal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import br.com.heybeauty.DrawerLayout.ConfiFragment;
import br.com.heybeauty.DrawerLayout.FavoritoFragment;
import br.com.heybeauty.DrawerLayout.PerfilUsuario;
import br.com.heybeauty.R;
import br.com.heybeauty.TelaPrincipal.BottomNavFragmets.AgendaFragment;
import br.com.heybeauty.TelaPrincipal.BottomNavFragmets.ChatFragment;
import br.com.heybeauty.TelaPrincipal.BottomNavFragmets.HomeFragment;
import br.com.heybeauty.TelaPrincipal.BottomNavFragmets.MapFragment;

public class Home extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private NavigationView sideNavigationView;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

            //DRAWER LAYOUT
        drawerLayout = findViewById(R.id.drawerLayoutPrincipal);

        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.text_abrir_menu, R.string.text_fechar_menu);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sideNavigationView = findViewById(R.id.navMenuLateral);

        final PerfilUsuario perfilUsuario = new PerfilUsuario();
        final ConfiFragment confiFragment = new ConfiFragment();
        final FavoritoFragment favoritoFragment = new FavoritoFragment();

        sideNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                    //Abrir fragmets Drawer
                int pu = menuItem.getItemId();
                if (pu == R.id.mnuItemPerfil){
                    setFragment(perfilUsuario);
                    return true;
                }
                else if (pu == R.id.mnuItemConfiguracao){
                    setFragment(confiFragment);
                    return true;
                }
                else if (pu == R.id.mnuItemFavoritos){
                    setFragment(favoritoFragment);
                    return true;
                }

                drawerLayout.closeDrawer(GravityCompat.START);
              return false;
            }
        });

        //DESIGN BOTTOM NAVEGATION
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);

        final HomeFragment homeFragment = new HomeFragment();
        final MapFragment mapFragment = new MapFragment();
        final ChatFragment chatFragment = new ChatFragment();
        final AgendaFragment agendaFragment = new AgendaFragment();

       bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                //Chamar os outros fragmentos ao clicar no bottom
                int id = menuItem.getItemId();
                    if (id == R.id.home){
                        setFragment(homeFragment);
                        return true;
                    }
                    else if (id == R.id.maps){
                        setFragment(mapFragment);
                        return true;
                    }
                    else if (id == R.id.chat){
                        setFragment(chatFragment);
                        return true;
                    }
                    else if (id == R.id.agenda){
                        setFragment(agendaFragment);
                        return true;
                    }

                return false;
            }
        });

        //Vir com a HomeFragment Selecionada
        bottomNavigationView.setSelectedItemId(R.id.home);
    }

    //DRAWER LAYOUT
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    private void setFragment (Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frmPrincipal, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

