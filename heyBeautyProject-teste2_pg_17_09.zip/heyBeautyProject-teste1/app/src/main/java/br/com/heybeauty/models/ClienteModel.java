package br.com.heybeauty.models;

public class ClienteModel {
    private String idCliente;
    private String cpf;

    private String obrservacoes;

    public ClienteModel() {
    }

    public ClienteModel(String idCliente, String cpf,  String obrservacoes) {
        this.idCliente = idCliente;
        this.cpf = cpf;
        this.obrservacoes = obrservacoes;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getObrservacoes() {
        return obrservacoes;
    }

    public void setObrservacoes(String obrservacoes) {
        this.obrservacoes = obrservacoes;
    }
}
