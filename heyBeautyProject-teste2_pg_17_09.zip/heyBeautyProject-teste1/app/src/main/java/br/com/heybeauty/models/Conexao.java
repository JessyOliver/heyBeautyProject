package br.com.heybeauty.models;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Conexao {

    public static DatabaseReference databaseReference;
    public static FirebaseDatabase firebaseDatabase;


    public static DatabaseReference iniciandoFirebase() {




        /////////////////////////////////////////////////
        //firebase inicializando
        //CHAMANDO O OBJETO DE CONEXÃO
       // FirebaseApp.initializeApp();

        /////////////////////////////////////////////
        firebaseDatabase = FirebaseDatabase.getInstance();

        //buscando os dados pra lista e atualizando
        firebaseDatabase.setPersistenceEnabled(true);

        //INICIANDO CONEXÃO
        databaseReference = firebaseDatabase.getReference();

        return databaseReference;
        ////fim iniciandoFirebase()
    }


    public Conexao() {
    }
}
