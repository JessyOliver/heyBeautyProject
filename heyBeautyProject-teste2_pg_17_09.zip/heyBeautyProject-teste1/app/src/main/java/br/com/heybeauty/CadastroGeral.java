package br.com.heybeauty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

import java.util.UUID;

import br.com.heybeauty.cadastro.Cadastro;
import br.com.heybeauty.classfuncoes.ValidadorEmail;
import br.com.heybeauty.models.Conexao;
import br.com.heybeauty.models.UsuarioModel;

public class CadastroGeral extends AppCompatActivity {

    ImageView imCadastro;

    EditText edtNomecad, edtDataNascicad, edtEnderecocad, edtEstadocad,
            edtCidadecad, edtTelcad, edtEmailcad,
            edtSenhacad, edtConfirmarSenhacad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_geral);


        inicializandoComponente();
        eventoClicks();
        Conexao.iniciandoFirebase();
        FirebaseApp.initializeApp(getApplicationContext());

    }

    private void inicializandoComponente() {
        imCadastro = (ImageView) findViewById(R.id.imgButton);

        /** CAIXAS DE TEXTO*/
        edtNomecad = (EditText)findViewById(R.id.edtNome_cad_geraltl);

        edtDataNascicad = (EditText)findViewById(R.id.edtNasc_cad_geraltl);

        edtEnderecocad = (EditText)findViewById(R.id.edtEndereco_cad_geraltl);

        edtEstadocad = (EditText)findViewById(R.id.edtEstado_cad_geraltl);

        edtCidadecad  = (EditText)findViewById(R.id.edtCidade_cad_geraltl);

        edtTelcad = (EditText)findViewById(R.id.edtTel_cad_geraltl);

        edtEmailcad  = (EditText)findViewById(R.id.edtEmail_cad_geraltl);

        edtSenhacad = (EditText)findViewById(R.id.edtSenha_cad_geraltl);

        edtConfirmarSenhacad = (EditText)findViewById(R.id.edtConfirmarSenha_cad_geraltl);


    }

    private void eventoClicks() {

        imCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /**VERIFICANDO SE AS SENHAS SÃO IDENTICAS*/
                if (edtNomecad.getText().toString().equals("")) {

                    edtNomecad.setError("Campo nome vazio.");
                    edtNomecad.requestFocus();

                }else
                if (edtDataNascicad.getText().toString().equals("")) {

                    edtDataNascicad.setError("Campo data nascimento vazio.");
                    edtDataNascicad.requestFocus();

                }else

                if (edtEnderecocad.getText().toString().equals("")) {

                    edtEnderecocad.setError("Campo endereço vazio.");
                    edtEnderecocad.requestFocus();

                }else
                if (edtEstadocad.getText().toString().equals("")) {

                    edtEstadocad.setError("Campo estado vazio.");
                    edtEstadocad.requestFocus();

                }else

                if (edtCidadecad.getText().toString().equals("")) {

                    edtCidadecad.setError("Campo cidade vazio.");
                    edtCidadecad.requestFocus();

                }else


                if (edtTelcad.getText().toString().equals("") || edtTelcad.length() < 11) {

                    edtTelcad.setError("Campo telefone vazio ou menor que onze digitos.");
                    edtTelcad.requestFocus();

                }else
                if (edtEmailcad.getText().toString().equals("")) {

                    edtEmailcad.setError("Campo email vazio.");
                    edtEmailcad.requestFocus();

                }else
                if (edtSenhacad.getText().toString().equals("")) {

                    edtSenhacad.setError("Campo senha vazio.");
                    edtSenhacad.requestFocus();



                }else
                if ( edtConfirmarSenhacad.getText().toString().equals("")){

                    edtConfirmarSenhacad.setError("Campo confirmação de senha vazio.");
                    edtConfirmarSenhacad.requestFocus();

                }else
                {
                    if (ValidadorEmail.vlEMAIL(edtEmailcad.getText().toString())){

                       // Toast.makeText(getApplicationContext(), "EMAIL ok", Toast.LENGTH_LONG).show();

                        /**VEIRIFICANDO SE OS CAMPOS SENHA SÃO IGUAIS*/
                        if (edtSenhacad.getText().toString().equals(edtConfirmarSenhacad.getText().toString())) {

                                    /**INICIANDO OS ENVIOS AO DB*/

                                    /**cha,mamdo class usuario geral*/
                                    UsuarioModel usug = new UsuarioModel();

                                    usug.setIdUsuarioGeral(UUID.randomUUID().toString());

                                    usug.setGeralNomecad(edtNomecad.getText().toString());

                                    usug.setGeralDatNascicad(edtDataNascicad.getText().toString());

                                    usug.setGeralEnderecocad(edtEnderecocad.getText().toString());

                                    usug.setGeralEstadocad(edtEstadocad.getText().toString());

                                    usug.setGeralCidadecad(edtCidadecad.getText().toString());

                                    usug.setGeralTelcad(edtTelcad.getText().toString());

                                    usug.setGeralEmailcad(edtEmailcad.getText().toString());

                                    usug.setGeralSenhacad(edtSenhacad.getText().toString());


                                    /**MANDANDO OS DADOS */
                                    Conexao.databaseReference.child("UsuarioGeral").child(usug.getIdUsuarioGeral()).setValue(usug);

                            Toast.makeText(getApplicationContext(), "Usuário cadastrado com sucesso!", Toast.LENGTH_LONG).show();

                                        // limparCampos();

                            //ultima função do botão
                            Intent tl = new Intent(getApplicationContext(), Cadastro.class);
                            startActivity(tl);

                            finish();

                        }
                        else {
                          //  Toast.makeText(getApplicationContext(), "Campos senha e confirmação de senha diferentes.", Toast.LENGTH_LONG).show();
                            edtSenhacad.setError("Campos senha e confirmação de senha diferentes.");
                            edtSenhacad.requestFocus();
                        }

                    }else {

                       // Toast.makeText(getApplicationContext(), "EMAIL Invalido", Toast.LENGTH_LONG).show();
                        edtEmailcad.setError("Email inválido.");
                        edtEmailcad.requestFocus();
                    }

                }
                /**FIM IF ELE*/

            }
        });

    }

    private void limparCampos() {


        /** limpando CAIXAS DE TEXTO*/
        edtNomecad.setText("");

        edtEnderecocad.setText("");

        edtEstadocad.setText("");

        edtCidadecad.setText("");

        edtTelcad.setText("");

        edtEmailcad.setText("");

        edtSenhacad.setText("");

        edtConfirmarSenhacad.setText("");

        edtNomecad.requestFocus();

    }
    /**Fim metodo limpar campos*/




}
/**fim tudo*/