package br.com.heybeauty.models;

public class ProfissionalModel {

    private String idProfissional;

    private String cpf;
    private String cargo;
    private String especializacao;

    public ProfissionalModel() {
    }


    public ProfissionalModel(String idProfissional, String cpf, String cargo, String especializacao) {
        this.idProfissional = idProfissional;

        this.cpf = cpf;
        this.cargo = cargo;
        this.especializacao = especializacao;
    }


    public String getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(String idProfissional) {
        this.idProfissional = idProfissional;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }


    @Override
    public String toString() {
        return cpf;
    }



}
