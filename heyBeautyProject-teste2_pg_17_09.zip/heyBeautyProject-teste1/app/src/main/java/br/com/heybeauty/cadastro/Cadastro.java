package br.com.heybeauty.cadastro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.FirebaseApp;


import br.com.heybeauty.CadastroProfissional;
import br.com.heybeauty.R;
import br.com.heybeauty.cadastro.adapters.CadastroFragmentPageAdapter;
import br.com.heybeauty.cadastro.fragments.FragmentProfissional;
import br.com.heybeauty.models.Conexao;

public class Cadastro extends AppCompatActivity /*implements FragmentProfissional.AbrirCadastro*/ {
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);


        tabLayout = findViewById(R.id.tblCadastro);
        viewPager = findViewById(R.id.vpg_cadastro);

        viewPager.setAdapter(new CadastroFragmentPageAdapter(getSupportFragmentManager(), getResources().getStringArray(R.array.titles_tab)));
        tabLayout.setupWithViewPager(viewPager);

        FirebaseApp.initializeApp(getApplicationContext());

    }

    /*@Override
    public void abrir() {

        CadastroProfissional cp = (CadastroProfissional) getSupportFragmentManager().findFragmentByTag();
    }*/
}