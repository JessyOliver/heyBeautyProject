package br.com.heybeauty.cadastro.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.FirebaseApp;

import java.util.UUID;

import br.com.heybeauty.R;
import br.com.heybeauty.TelaPrincipal.Home;
import br.com.heybeauty.classfuncoes.ValidadorCpf;
import br.com.heybeauty.models.ClienteModel;
import br.com.heybeauty.models.Conexao;

public class FragmentUsuario extends Fragment {

    EditText edt_cpf,  edt_alergias;

    Button btnCadastra;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fragment_usuario, container, false);



    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edt_cpf = (EditText)view.findViewById(R.id.edtCpf_cad_clientetl);


        edt_alergias = (EditText)view.findViewById(R.id.edtAlergias_cad_clientetl);

        btnCadastra = (Button)view.findViewById(R.id.btnCad_cad_clientetl);

        btnCadastra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edt_cpf.getText().length() < 11){

                    edt_cpf.setError("Campo cpf com a numeração incompleta.");
                    edt_cpf.requestFocus();

                }else  {

                        if (ValidadorCpf.isCpf(edt_cpf.getText().toString()) ==  true){


                                ClienteModel clicad = new ClienteModel();

                                clicad.setIdCliente(UUID.randomUUID().toString());

                                clicad.setCpf(edt_cpf.getText().toString());

                                clicad.setObrservacoes(edt_alergias.getText().toString());

                                Conexao.databaseReference.child("Cliente").child(clicad.getIdCliente()).setValue(clicad);

                            Toast.makeText(getContext(), "Cliente cadastrado com sucesso.", Toast.LENGTH_LONG).show();

                            Intent telaHome = new Intent(getActivity(), Home.class);
                            startActivity(telaHome);


                        }
                        else {

                            edt_cpf.setError("Cpf inválido.");
                            edt_cpf.requestFocus();

                        }
                }
                /** Fim if else*/
            }
        });

    }


}