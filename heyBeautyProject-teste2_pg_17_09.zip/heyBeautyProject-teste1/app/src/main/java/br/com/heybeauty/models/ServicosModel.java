package br.com.heybeauty.models;

public class ServicosModel {
    private String idEmpresa;
    private String cuidados;
    private String descricao;
    private int[] duracao;
    private String imagem;
    private float preco;
    private String[] produtos;
    private String tipo;
    private String titulo;

    public ServicosModel() {
    }

    public ServicosModel(String idEmpresa, String cuidados, String descricao, int[] duracao, String imagem, float preco, String[] produtos, String tipo, String titulo) {
        this.idEmpresa = idEmpresa;
        this.cuidados = cuidados;
        this.descricao = descricao;
        this.duracao = duracao;
        this.imagem = imagem;
        this.preco = preco;
        this.produtos = produtos;
        this.tipo = tipo;
        this.titulo = titulo;
    }

    public String getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(String idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getCuidados() {
        return cuidados;
    }

    public void setCuidados(String cuidados) {
        this.cuidados = cuidados;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int[] getDuracao() {
        return duracao;
    }

    public void setDuracao(int[] duracao) {
        this.duracao = duracao;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String[] getProdutos() {
        return produtos;
    }

    public void setProdutos(String[] produtos) {
        this.produtos = produtos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
