package br.com.heybeauty;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import br.com.heybeauty.TelaPrincipal.Home;

public class LoginHB extends AppCompatActivity {

    Button btnEntrar;
    TextView txCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_hb);

            //Ir para a tela Home
        btnEntrar = (Button)findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ip = new Intent(LoginHB.this, Home.class);
                startActivity(ip);
            }
        });

        //Ir para a tela Cadastro geral
      txCadastro = (TextView) findViewById(R.id.txtCadastro);

      txCadastro.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Intent cd = new Intent(LoginHB.this, CadastroGeral.class);
              startActivity(cd);
          }
      });
    }
}
