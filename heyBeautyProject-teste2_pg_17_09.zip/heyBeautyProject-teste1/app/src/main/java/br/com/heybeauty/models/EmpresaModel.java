package br.com.heybeauty.models;

public class EmpresaModel {
    private String idEmpresa;

    private String nome_empresa;

    private String tipo_empresa;

    private String cnpj_empresa;

    private String cevs_empresa;

    private String endereco_empresa;

    private String cidade_empresa;

    private String estado_empresa;

    private String telefone_empresa;

    private String celular_empresa;



    public EmpresaModel() {
    }



    public EmpresaModel(String idEmpresa, String nome_empresa, String tipo_empresa, String cnpj_empresa, String cevs_empresa, String endereco_empresa, String cidade_empresa, String estado_empresa, String telefone_empresa, String celular_empresa) {
        this.idEmpresa = idEmpresa;
        this.nome_empresa = nome_empresa;
        this.tipo_empresa = tipo_empresa;
        this.cnpj_empresa = cnpj_empresa;
        this.cevs_empresa = cevs_empresa;
        this.endereco_empresa = endereco_empresa;
        this.cidade_empresa = cidade_empresa;
        this.estado_empresa = estado_empresa;
        this.telefone_empresa = telefone_empresa;
        this.celular_empresa = celular_empresa;
    }



    public String getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(String idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getNome_empresa() {
        return nome_empresa;
    }

    public void setNome_empresa(String nome_empresa) {
        this.nome_empresa = nome_empresa;
    }

    public String getTipo_empresa() {
        return tipo_empresa;
    }

    public void setTipo_empresa(String tipo_empresa) {
        this.tipo_empresa = tipo_empresa;
    }

    public String getCnpj_empresa() {
        return cnpj_empresa;
    }

    public void setCnpj_empresa(String cnpj_empresa) {
        this.cnpj_empresa = cnpj_empresa;
    }

    public String getCevs_empresa() {
        return cevs_empresa;
    }

    public void setCevs_empresa(String cevs_empresa) {
        this.cevs_empresa = cevs_empresa;
    }

    public String getEndereco_empresa() {
        return endereco_empresa;
    }

    public void setEndereco_empresa(String endereco_empresa) {
        this.endereco_empresa = endereco_empresa;
    }

    public String getCidade_empresa() {
        return cidade_empresa;
    }

    public void setCidade_empresa(String cidade_empresa) {
        this.cidade_empresa = cidade_empresa;
    }

    public String getEstado_empresa() {
        return estado_empresa;
    }

    public void setEstado_empresa(String estado_empresa) {
        this.estado_empresa = estado_empresa;
    }

    public String getTelefone_empresa() {
        return telefone_empresa;
    }

    public void setTelefone_empresa(String telefone_empresa) {
        this.telefone_empresa = telefone_empresa;
    }

    public String getCelular_empresa() {
        return celular_empresa;
    }

    public void setCelular_empresa(String celular_empresa) {
        this.celular_empresa = celular_empresa;
    }



   @Override
    public String toString() {
        return tipo_empresa ;
    }


}
