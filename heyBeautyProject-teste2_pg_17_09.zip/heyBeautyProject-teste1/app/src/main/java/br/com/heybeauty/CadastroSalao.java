package br.com.heybeauty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

import java.util.UUID;

import br.com.heybeauty.TelaPrincipal.Home;
import br.com.heybeauty.classfuncoes.ValidadorCNPJ;
import br.com.heybeauty.models.Conexao;
import br.com.heybeauty.models.EmpresaModel;

public class CadastroSalao extends AppCompatActivity {

    EditText edt_nome_empresa, edt_tipo_empresa, edt_cnpj_empresa,
                edt_cevs_empresa, edt_endere_empresa, edt_cidade_empresa,
                    edt_estado_empresa, edt_telefone_empresa, edt_celular_empresa;

    Button btncad_salao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_salao);

        iniciandoCamponentes();

        funcaoBotao();


        FirebaseApp.initializeApp(getApplication());

    }


    private void iniciandoCamponentes() {

        edt_nome_empresa = (EditText) findViewById(R.id.edtNomeEmpresa_cadtl);

        edt_tipo_empresa = (EditText)findViewById(R.id.edtTipoEmpresa_cadtl);

        edt_cnpj_empresa = (EditText)findViewById(R.id.edtCnpjEmpresa_cadtl);

        edt_cevs_empresa = (EditText)findViewById(R.id.edtCevsEmpresa_cadtl);

        edt_endere_empresa = (EditText)findViewById(R.id.edtEnderecoEmpresa_cadtl);

        edt_cidade_empresa= (EditText)findViewById(R.id.edtCidadeEmpresa_cadtl);

        edt_estado_empresa = (EditText)findViewById(R.id.edtEstadoEmpresa_cadtl);

        edt_telefone_empresa = (EditText)findViewById(R.id.edtTelEmpresa_cadtl);

        edt_celular_empresa = (EditText)findViewById(R.id.edtCelEmpresa_cadtl);

        btncad_salao= (Button)findViewById(R.id.btnCadastroEmpresa_cadtl);


    }


    private void funcaoBotao() {

        btncad_salao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             if (edt_nome_empresa.getText().toString().equals("")){

                    edt_nome_empresa.setError("Campo nome está vazio.");
                    edt_nome_empresa.requestFocus();

                }
                else  if (edt_tipo_empresa.getText().toString().equals("")){

                    edt_tipo_empresa.setError("Campo tipo está vazio.");
                    edt_tipo_empresa.requestFocus();

                }
                else if (edt_cnpj_empresa.getText().toString().equals("") || edt_cnpj_empresa.getText().toString().length() < 14){

                    edt_cnpj_empresa.setError("Campo CNPJ está vazio ou numeros menores que 14.");
                    edt_cnpj_empresa.requestFocus();
                }
                else if (edt_cevs_empresa.getText().toString().equals("")){

                    edt_cevs_empresa.setError("Campo CNPJ está vazio. ");
                    edt_cevs_empresa.requestFocus();

                }
                else if(edt_endere_empresa.getText().toString().equals("")){

                    edt_endere_empresa.setError("Campo endereço está vazio.");
                    edt_endere_empresa.requestFocus();

                }
                else if (edt_cidade_empresa.getText().toString().equals("")){

                    edt_cidade_empresa.setError("Campo cidade está vazio.");
                    edt_cidade_empresa.requestFocus();

                }
                else if (edt_estado_empresa.getText().toString().equals("")){

                    edt_estado_empresa.setError("Campo estado está vazio.");
                    edt_estado_empresa.requestFocus();

                }
                else if (edt_telefone_empresa.getText().toString().equals("") && edt_celular_empresa.getText().toString().equals("")){

                    edt_telefone_empresa.setError("Campo telefone ou celular estão vazios, favor preencher um dos campo.");
                    edt_telefone_empresa.requestFocus();

                }else {


                    if (ValidadorCNPJ.vlCNPJ(edt_cnpj_empresa.getText().toString()) == true){

                        EmpresaModel empre_cad = new EmpresaModel();

                        empre_cad.setIdEmpresa(UUID.randomUUID().toString());

                        empre_cad.setNome_empresa(edt_nome_empresa.getText().toString());

                        empre_cad.setTipo_empresa(edt_tipo_empresa.getText().toString());

                        empre_cad.setCnpj_empresa(edt_cnpj_empresa.getText().toString());

                        empre_cad.setCevs_empresa(edt_cevs_empresa.getText().toString());

                        empre_cad.setEndereco_empresa(edt_endere_empresa.getText().toString());

                        empre_cad.setCidade_empresa(edt_cidade_empresa.getText().toString());

                        empre_cad.setEstado_empresa(edt_estado_empresa.getText().toString());

                        empre_cad.setTelefone_empresa(edt_telefone_empresa.getText().toString());

                        empre_cad.setCelular_empresa(edt_celular_empresa.getText().toString());


                        Conexao.databaseReference.child("Empresa").child(empre_cad.getIdEmpresa()).setValue(empre_cad);


                        Toast.makeText(getApplication(), "Cadastro realizado com sucesso", Toast.LENGTH_LONG).show();

                        Intent empresatl = new Intent(getApplication(), Home.class);
                        startActivity(empresatl);


                    }
                    else {

                        edt_cnpj_empresa.setError("CNPJ inválido.");
                        edt_cnpj_empresa.requestFocus();

                    }




                }/** fim if else*/

            }
        });


    }





}
