package br.com.heybeauty.cadastro.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.UUID;

import br.com.heybeauty.CadastroProfissional;
import br.com.heybeauty.R;
import br.com.heybeauty.classfuncoes.ValidadorCpf;
import br.com.heybeauty.models.Conexao;
import br.com.heybeauty.models.ProfissionalModel;

public class FragmentProfissional extends Fragment {
    private View.OnClickListener listener;

    EditText edt_cpf, edt_cargo, edt_especializacao;

    Button btn_cad_profissinal;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fragment_profissional,container, false);

    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        edt_cpf = (EditText)view.findViewById(R.id.edtCpfProfi_cad);

        edt_cargo = (EditText)view.findViewById(R.id.edtCargo_cad_prof);

        edt_especializacao =(EditText)view.findViewById(R.id.edtEspecializacao_cad_prof);

        btn_cad_profissinal = (Button) view.findViewById(R.id.btncad_prox_tl_Profi_cad);


        btn_cad_profissinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getContext(), "Vai chamar o fragmento", Toast.LENGTH_SHORT).show();

                /*FragmentManager fragmentTransaction = getActivity().getSupportFragmentManager();
                FragmentTransaction transaction = fragmentTransaction.beginTransaction();
                //CadastroProfissional mudarFragment = new CadastroProfissional();
                FragmentUsuario mudarFragment = new FragmentUsuario();
                transaction.replace(R.id.conteudo, mudarFragment);
                transaction.addToBackStack(null);
                transaction.commit();*/

                if (edt_cpf.getText().toString().equals("") || edt_cpf.getText().toString().length() < 11){

                        edt_cpf.setError("Campo CPF com digitos inferior a 11 ou campo em branco.");
                        edt_cpf.requestFocus();
                }
                else if (edt_cargo.getText().toString().equals("")){

                    edt_cargo.setError("Campo vazio.");
                    edt_cargo.requestFocus();
                }
                else if(edt_especializacao.getText().toString().equals("")){

                    edt_especializacao.setError("Campo especialização vazio.");
                    edt_especializacao.requestFocus();

                }else{

                        if (ValidadorCpf.isCpf(edt_cpf.getText().toString()) == true){

                                ProfissionalModel procad = new ProfissionalModel();

                                procad.setIdProfissional(UUID.randomUUID().toString());

                                procad.setCpf(edt_cpf.getText().toString());

                                procad.setCargo(edt_cargo.getText().toString());

                                procad.setEspecializacao(edt_especializacao.getText().toString());

                                Conexao.databaseReference.child("Profissional").child(procad.getIdProfissional()).setValue(procad);

                            Toast.makeText(getContext(), "Cadastro realizado com sucesso.", Toast.LENGTH_LONG).show();

                            Intent telaProx = new Intent(getActivity(), CadastroProfissional.class);
                            startActivity(telaProx);

                        }else {

                            edt_cpf.setError("CPF inválido.");
                            edt_cpf.requestFocus();
                        }



                }//fim if else


            }
        });
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }
}