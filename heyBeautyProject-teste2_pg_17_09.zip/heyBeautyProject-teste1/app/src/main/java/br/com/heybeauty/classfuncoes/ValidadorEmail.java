package br.com.heybeauty.classfuncoes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidadorEmail {


    public static String EmailIdValid;

    public ValidadorEmail() {
    }


    public static boolean vlEMAIL( String email ){

        boolean EmailIdValid = false;
        if (email != null && email.length() > 0) {
            String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
            Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(email);
            if (matcher.matches()) {
                EmailIdValid = true;
            }
        }
        return EmailIdValid;
    }


    
}


